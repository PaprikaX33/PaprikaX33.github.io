![iconLogo](/src/main/resources/static/base/logo.png)

# Perforum2
A forum suite build with springboot and thymeleaf

## Purpose
This program is build for Software engineering course assignment

## License
Licensed as unlicense.
additional information can be found in [here](https://unlicense.org/)
