package iuli.perforum2.services;

import iuli.perforum2.models.Thread;
import iuli.perforum2.models.Tag;
import iuli.perforum2.models.Account;

import java.util.List;

public interface ThreadService {
    List<Thread> getThreadByTag(Tag tag);
    List<Thread> getAllThread();
    List<Thread> getPossibleSubscribe(Account acc);
    Thread emptyThread();
    Thread getThreadById(Long threadID);
    Thread newThread(Thread thred);
    void deleteThreadByID(Long threadID);
}
