package iuli.perforum2.services;

import iuli.perforum2.models.Account;

import java.util.List;

public interface AccountService {
    List<Account> getAll();
    Account getAccountById(Long accountID);
    Account newAccount(Account acc);
    Account setSubscribe(Long accountID, Long threadID);
    void deleteAccByID(long accountID);
}
