package iuli.perforum2.services;

import iuli.perforum2.models.Role;
import iuli.perforum2.models.repositories.RoleRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImplementation implements RoleService {
    @Autowired
    RoleRepository repo;

    public List<Role> getAll(){
        return repo.findAll();
    }
}
