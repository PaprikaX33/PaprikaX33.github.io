package iuli.perforum2.services;

import iuli.perforum2.models.Tag;
import iuli.perforum2.models.repositories.TagRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TagServiceImplementation implements TagService {
    @Autowired
    TagRepository repo;

    public List<Tag> getAll(){
        return repo.findAll();
    }
    public Tag getTagById(Long tagID){
        Optional<Tag> retCode = repo.findById(tagID);
        if(!retCode.isPresent()){
            throw new RuntimeException();
        }
        return retCode.get();
    }
}
