package iuli.perforum2.services;

import iuli.perforum2.models.Thread;
import iuli.perforum2.models.Tag;
import iuli.perforum2.models.Account;
import iuli.perforum2.models.repositories.ThreadRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ThreadServiceImplementation implements ThreadService {
    @Autowired
    ThreadRepository repo;
    @Override
    public List<Thread> getThreadByTag(Tag tag){
        return repo.findByTags(tag);
    }
    @Override
    public List<Thread> getAllThread(){
        return repo.findAll();
    }

    public List<Thread> getPossibleSubscribe(Account acc){
        return repo.findAllBySubscriberIsNot(acc);
    }
    @Override
    public Thread emptyThread() {
        Thread tempThread = new Thread();
        tempThread.setTitle("Untitled");
        return tempThread;
    }
    @Override
    public Thread getThreadById(Long threadID){
        Optional<Thread> retCode = repo.findById(threadID);
        if(!retCode.isPresent()){
            throw new RuntimeException();
        }
        return retCode.get();
    }
    @Override
    public Thread newThread(Thread thred){
        //thred.setCreatedDate()
        return repo.save(thred);
    }
    @Override
    public void deleteThreadByID(Long threadID){
        repo.deleteById(threadID);
    }
}
