package iuli.perforum2.services;

import iuli.perforum2.models.Message;
import iuli.perforum2.models.Thread;
import iuli.perforum2.models.Tag;

import java.util.List;

public interface MessageService {
    List<Message> getAllMessage();
    Message emptyMessage();
    Message getMessageById(Long messageID);
    Message newMessage(Message message, Thread threadPos);
    void deleteMessageByID(Long messageID);
}
