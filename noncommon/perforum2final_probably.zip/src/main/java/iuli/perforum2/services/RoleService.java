package iuli.perforum2.services;

import iuli.perforum2.models.Role;

import java.util.List;

public interface RoleService{
    List<Role> getAll();
}
