package iuli.perforum2.services;

import iuli.perforum2.models.Tag;

import java.util.List;

public interface TagService{
    List<Tag> getAll();
    Tag getTagById(Long tagID);
}
