package iuli.perforum2.services;

import iuli.perforum2.models.Message;
import iuli.perforum2.models.Tag;
import iuli.perforum2.models.Thread;
import iuli.perforum2.models.repositories.MessageRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Date;
import java.util.Optional;

@Service
public class MessageServiceImplementation implements MessageService {
    @Autowired
    MessageRepository repo;

    @Override
    public List<Message> getAllMessage(){
        return repo.findAll();
    }
    @Override
    public Message emptyMessage(){
        return new Message();
    }
    @Override
    public Message getMessageById(Long messageID){
        Optional<Message> retCode = repo.findById(messageID);
        if(!retCode.isPresent()){
            throw new RuntimeException();
        }
        return retCode.get();
    }
    @Override
    public Message newMessage(Message message, Thread threadPos){
        if(message.getText() == null || message.getText().trim().isEmpty()){
            return message;
        }
        message.setThread(threadPos);
        message.setPostDate(new Date());
        return repo.save(message);
    }
    @Override
    public void deleteMessageByID(Long messageID){
        repo.deleteById(messageID);
    }
}
