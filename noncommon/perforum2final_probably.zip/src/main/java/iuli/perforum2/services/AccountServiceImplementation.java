package iuli.perforum2.services;

import iuli.perforum2.models.Account;
import iuli.perforum2.models.Thread;
import iuli.perforum2.models.Tag;
import iuli.perforum2.models.Message;
import iuli.perforum2.models.repositories.AccountRepository;
import iuli.perforum2.services.ThreadService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AccountServiceImplementation implements AccountService {
    @Autowired
    AccountRepository repo;

    @Autowired
    ThreadService threadServ;

    public List<Account> getAll(){
        return repo.findAll();
    }
    public Account getAccountById(Long accountID){
        Optional<Account> retCode = repo.findById(accountID);
        if(!retCode.isPresent()){
            throw new RuntimeException();
        }
        return retCode.get();
    }

    public Account newAccount(Account acc){
        // acc.setPostedMessage(new List<Message>());
        // acc.setPostedThread(new List<Thread>());
        // acc.setSubscribed(new List<Thread>());
        // acc.setFavTags(new List<Tag>());
        //acc.setEmail("no_reply@nowhere.moe");
        acc.setEmail(acc.getUserName() + "@no_reply.nowhere.moe");
        acc.setPassword("...");
        return repo.save(acc);
    }
    public Account setSubscribe(Long accountID, Long threadID){
        Optional<Account> retCode = repo.findById(accountID);
        if(!retCode.isPresent()){
            throw new RuntimeException();
        }
        Account acc = retCode.get();
        List<Thread> subslist= acc.getSubscribed();
        subslist.add(threadServ.getThreadById(threadID));
        acc.setSubscribed(subslist);
        return repo.save(acc);
    }
    public void deleteAccByID(long accountID){
        repo.deleteById(accountID);
    }
}
