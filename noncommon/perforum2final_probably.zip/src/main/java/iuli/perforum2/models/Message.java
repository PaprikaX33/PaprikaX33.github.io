package iuli.perforum2.models;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "message")
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String text;
    private Date postDate;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = Thread.class)
    @JoinColumn(name = "thread_id")
    private Thread thread;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = Account.class)
    @JoinColumn(name = "author_id")
    private Account author;

    public Message(){}
    public Long getId(){
        return id;
    }
    public void setId(Long id){
        this.id = id;
    }
    public String getText(){
        return text;
    }
    public void setText(String text){
        this.text = text;
    }
    public Date getPostDate(){
        return postDate;
    }
    public void setPostDate(Date postDate){
        this.postDate = postDate;
    }

    public Thread getThread(){
        return thread;
    }
    public void setThread(Thread thread){
        this.thread = thread;
    }

    public Account getAuthor(){
        return author;
    }
    public void setAuthor(Account author){
        this.author = author;
    }

}
