package iuli.perforum2.models.repositories;

import iuli.perforum2.models.ForumUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ForumUserRepository extends JpaRepository<ForumUser, Long> {

}
