package iuli.perforum2.models.repositories;

import iuli.perforum2.models.Message;
import iuli.perforum2.models.Thread;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {
    //List<Message> findByThreadByOrderByPostDate(Thread thread);
    List<Message> findByThread(Thread thread);
}
