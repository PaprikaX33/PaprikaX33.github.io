package iuli.perforum2.models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "role")
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String roleName;
    private Boolean post;
    private Boolean delete;
    private Boolean modif;

    @OneToMany(cascade = CascadeType.ALL,
               fetch = FetchType.LAZY,
               mappedBy ="role")
               private List<Account> userList;

    public Role(){}
    public Long getId(){
        return id;
    }
    public void setId(Long id){
        this.id = id;
    }

    public String getRoleName(){
        return roleName;
    }
    public void setRoleName(String roleName){
        this.roleName = roleName;
    }
    public Boolean getPost(){
        return post;
    }
    public void setPost(Boolean post){
        this.post = post;
    }
    public Boolean getDelete(){
        return delete;
    }
    public void setDelete(Boolean delete){
        this.delete = delete;
    }
    public Boolean getModif(){
        return modif;
    }
    public void setModif(Boolean modif){
        this.modif = modif;
    }

    public List<Account> getUserList(){
        return userList;
    }
    public void setUserList(List<Account> userList){
        this.userList = userList;
    }

}
