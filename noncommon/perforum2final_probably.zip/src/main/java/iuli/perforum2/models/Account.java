package iuli.perforum2.models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "account")
public class Account{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String userName;
    private String password;
    private String email;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = Role.class)
    @JoinColumn(name = "role_id")
    private Role role;

    @OneToMany(cascade = CascadeType.ALL,
               fetch = FetchType.LAZY,
               mappedBy ="author")
               private List<Thread> postedThread;
    @OneToMany(cascade = CascadeType.ALL,
               fetch = FetchType.LAZY,
               mappedBy ="author")
               private List<Message> postedMessage;

    @ManyToMany
    @JoinTable(name = "fav_tag_list",
               joinColumns = @JoinColumn(name = "user_id"),
               inverseJoinColumns = @JoinColumn(name = "tag_id"))
               private List<Tag>favTags;

    @ManyToMany
    @JoinTable(name = "subscribe_list",
               joinColumns = @JoinColumn(name = "user_id"),
               inverseJoinColumns = @JoinColumn(name = "thread_id"))
               private List<Thread>subscribed;

    public Long getId(){
        return id;
    }
    public void setId(Long id){
        this.id = id;
    }
    public String getUserName(){
        return userName;
    }
    public void setUserName(String userName){
        this.userName = userName;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public Role getRole(){
        return role;
    }
    public void setRole(Role role){
        this.role = role;
    }
    public List<Thread> getPostedThread(){
        return postedThread;
    }
    public void setPostedThread(List<Thread> postedThread){
        this.postedThread = postedThread;
    }
    public List<Message> getPostedMessage(){
        return postedMessage;
    }
    public void setPostedMessage(List<Message> postedMessage){
        this.postedMessage = postedMessage;
    }
    public List<Tag> getFavTags(){
        return favTags;
    }
    public void setFavTags(List<Tag> favTags){
        this.favTags = favTags;
    }
    public List<Thread> getSubscribed(){
        return subscribed;
    }
    public void setSubscribed(List<Thread> subscribed){
        this.subscribed = subscribed;
    }

}
