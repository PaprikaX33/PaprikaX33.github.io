package iuli.perforum2.models.repositories;

import iuli.perforum2.models.Tag;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TagRepository extends JpaRepository<Tag, Long> {

}
