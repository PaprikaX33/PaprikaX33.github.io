package iuli.perforum2.models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "thread")
public class Thread {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = Account.class)
    private Account author;

    @ManyToMany
    @JoinTable(name = "tag_list",
               joinColumns = @JoinColumn(name = "thread_id"),
               inverseJoinColumns = @JoinColumn(name = "tag_id"))
               private List<Tag>tags;

    @OneToMany(cascade = CascadeType.ALL,
               fetch = FetchType.LAZY,
               mappedBy ="thread")
               private List<Message> message;

    @ManyToMany(mappedBy="subscribed")
    private List<Account>subscriber;

    public Long getId(){
        return id;
    }
    public void setId(Long id){
        this.id = id;
    }
    public String getTitle(){
        return title;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public Account getAuthor(){
        return author;
    }
    public void setAuthor(Account author){
        this.author = author;
    }

    public List<Tag> getTags(){
        return tags;
    }
    public void setTags(List<Tag> tags){
        this.tags = tags;
    }
    public List<Message> getMessage(){
        return message;
    }
    public void setMessage(List<Message> message){
        this.message = message;
    }
    public List<Account> getSubscriber(){
        return subscriber;
    }
    public void setSubscriber(List<Account> subscriber){
        this.subscriber = subscriber;
    }


}
