package iuli.perforum2.models.repositories;

import iuli.perforum2.models.Thread;
import iuli.perforum2.models.Tag;
import iuli.perforum2.models.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ThreadRepository extends JpaRepository<Thread, Long> {
    List<Thread> findByTags(Tag tags);
    List<Thread> findAllBySubscriberIsNot(Account subscriber);
}
