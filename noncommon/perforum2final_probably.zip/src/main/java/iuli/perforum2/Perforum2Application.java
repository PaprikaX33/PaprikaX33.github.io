package iuli.perforum2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Perforum2Application {

	public static void main(String[] args) {
		SpringApplication.run(Perforum2Application.class, args);
	}

}
