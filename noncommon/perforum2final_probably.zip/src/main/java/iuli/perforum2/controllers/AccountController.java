package iuli.perforum2.controllers;

import iuli.perforum2.models.Account;
import iuli.perforum2.services.AccountService;
import iuli.perforum2.services.TagService;
import iuli.perforum2.services.RoleService;
import iuli.perforum2.services.ThreadService;
//import iuli.perforum2.models.repositories.AccountRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/account")
public class AccountController {
    @Autowired
    AccountService serv;

    @Autowired
    TagService tagServ;

    @Autowired
    RoleService roleServ;

    @Autowired
    ThreadService threadServ;

    @GetMapping("/list")
    public ModelAndView index(ModelAndView mView){
        mView.addObject("accList", serv.getAll());
        mView.addObject("data", new Account());
        mView.addObject("tagList", tagServ.getAll());
        mView.addObject("rolList", roleServ.getAll());
        mView.setViewName("pages/account/accountList");
        return mView;
    }

    @GetMapping("/{accID}/delete")
    public ModelAndView deleteThread(ModelAndView mView,
                                     @PathVariable Long accID){
        serv.deleteAccByID(accID);
        mView.setViewName("redirect:/account/list");
        return mView;
    }

    @GetMapping("/{accID}")
    public ModelAndView view(ModelAndView mView,
                             @PathVariable Long accID){
        mView.addObject("acc", serv.getAccountById(accID));
        mView.addObject("subPossible", threadServ.getPossibleSubscribe(serv.getAccountById(accID)));
        mView.setViewName("pages/account/accountDetail");
        return mView;
    }

    @PostMapping("/new")
    public ModelAndView postReceive(@ModelAttribute(name = "data") Account acc,
                                    ModelAndView mView){
        serv.newAccount(acc);
        mView.setViewName("redirect:/account/list");
        return mView;
    }
    @GetMapping("/sub/{accID}/{thrdID}")
    public ModelAndView view(ModelAndView mView,
                             @PathVariable Long accID,
                             @PathVariable Long thrdID){
        serv.setSubscribe(accID, thrdID);
        mView.setViewName("redirect:/account/" + String.valueOf(accID));
        return mView;
    }
}
