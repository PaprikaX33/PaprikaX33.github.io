package iuli.perforum2.controllers;

import iuli.perforum2.models.Thread;
import iuli.perforum2.models.Message;
import iuli.perforum2.services.TagService;
import iuli.perforum2.services.AccountService;
import iuli.perforum2.services.MessageService;
//import iuli.perforum2.models.repositories.ThreadRepository;
import iuli.perforum2.services.ThreadService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/thread")
public class ThreadController {
    @Autowired
    ThreadService serv;
    @Autowired
    TagService tagServ;
    @Autowired
    AccountService accServ;
    @Autowired
    MessageService msgServ;

    @GetMapping("/list")
    public ModelAndView index(ModelAndView mView){
        //List<Thread> uList = repo.findAll();
        List<Thread> uList = serv.getAllThread();
        mView.addObject("thrdList", uList);
        mView.addObject("newThreadData", serv.emptyThread());
        mView.addObject("tagList", tagServ.getAll());
        mView.addObject("accList", accServ.getAll());
        mView.setViewName("pages/thread/threadList");
        return mView;
    }

    @GetMapping("/{threadID}/delete")
    public ModelAndView deleteThread(ModelAndView mView,
                                     @PathVariable Long threadID){
        serv.deleteThreadByID(threadID);
        mView.setViewName("redirect:/thread/list");
        return mView;
    }

    @GetMapping("/{threadID}")
    public ModelAndView view(ModelAndView mView,
                             @PathVariable Long threadID){
        mView.addObject("messageData", msgServ.emptyMessage());
        mView.addObject("thrd", serv.getThreadById(threadID));
        mView.addObject("accList", accServ.getAll());
        mView.setViewName("pages/thread/threadMessage");
        return mView;
    }

    @PostMapping("/new")
    public ModelAndView newThread(@ModelAttribute(name = "newThreadData") Thread thread,
                                  ModelAndView mView){
        serv.newThread(thread);
        mView.setViewName("redirect:/thread/list");
        return mView;
    }

    @PostMapping("/{threadID}/post")
    public ModelAndView postReceive(@ModelAttribute(name = "messageData") Message msg,
                                    ModelAndView mView,
                                    @PathVariable Long threadID){
        msgServ.newMessage(msg, serv.getThreadById(threadID));
        mView.setViewName("redirect:/thread/" + String.valueOf(threadID));
        return mView;
    }
}
