package iuli.perforum2.controllers;

import iuli.perforum2.models.ForumUser;
import iuli.perforum2.models.repositories.ForumUserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class ForumUserController {
    @Autowired
    ForumUserRepository repo;
    @GetMapping("/user")
    public ModelAndView index(ModelAndView mView){
        List<ForumUser> uList = repo.findAll();
        mView.addObject("userList", uList);
        mView.setViewName("pages/user/userList");
        return mView;
    }
}
